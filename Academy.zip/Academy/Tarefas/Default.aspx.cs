﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Tarefas_Default : System.Web.UI.Page
{
    Academy.Business.Task task = new Academy.Business.Task();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            GetTasks();
        }
    }

    private void GetTasks()
    {
        task.getTasks();
        Session.Add("Tasks", task);
        GetAllTasks();
    }

    private void GetAllTasks()
    {
        task = (Academy.Business.Task)Session["Tasks"];
        FillTasksOnGrid(task);
    }

    private void DeleteTasks(int id)
    {
        task = (Academy.Business.Task)Session["Tasks"];
        task.DeleteTask(id);
        ReloadTasks();
    }

    private void ReloadTasks()
    {
        task.getTasks();
        Session["Tasks"] = task;
        GetAllTasks();
    }

    protected void gdvTarefas_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvTarefas.PageIndex = e.NewPageIndex;
        GetAllTasks();
    }

    protected void gdvTarefas_RowDataBound(object sender, GridViewRowEventArgs e)
    {
        var lnkDelete = (LinkButton)e.Row.FindControl("lnkDelete");

        if (lnkDelete != null)
        {
            if (!lnkDelete.Enabled)
            {
                lnkDelete.OnClientClick = null;
                e.Row.BackColor = System.Drawing.Color.FloralWhite;
                e.Row.ForeColor = System.Drawing.Color.Red;
            }
        }

    }

    protected void EditTask(object sender, EventArgs e)
    {
        var id = (sender as LinkButton).CommandArgument;

        task = (Academy.Business.Task)Session["Tasks"];
        var item = task.Tasks.Where(i => i.Id.Equals(Convert.ToInt32(id))).FirstOrDefault();

        Tittle.Text = item.Tittle;
        Tittle.Enabled = item.Delete;
        Description.Text = item.Description;
        Description.Enabled = item.Delete;
        ExpireOn.Text = item.ExpireOn.ToString("yyyy-MM-dd");
        ExpireOn.Enabled = item.Delete;
        Id.Value = id;
        btnSalvar.Enabled = item.Delete;
        btnSalvar.ToolTip = "Tarefa expirada não pode ser editada!";
        btnSalvar.CssClass = "btn btn-light";
        pnlNewTask.Visible = true;
        pnlTask.Visible = false;
    }

    protected void DeleteTask(object sender, EventArgs e)
    {
        var id = (sender as LinkButton).CommandArgument;
        DeleteTasks(Convert.ToInt32(id));
    }

    protected void NewTask(object sender, EventArgs e)
    {
        pnlNewTask.Visible = true;
        pnlTask.Visible = false;
    }

    protected void SaveTask(object sender, EventArgs e)
    {
        if (string.IsNullOrEmpty(Tittle.Text) || string.IsNullOrEmpty(Description.Text))
            return;

        if (!string.IsNullOrEmpty(Id.Value))
        {
            task.UpdateTask(
                Convert.ToInt32(Id.Value),
                Tittle.Text,
                Description.Text,
                Convert.ToDateTime(ExpireOn.Text, System.Globalization.CultureInfo.GetCultureInfo("pt-BR").DateTimeFormat));
        }
        else
        {
            task.CreateTask(
                Tittle.Text,
                Description.Text,
                DateTime.Now,
                Convert.ToDateTime(ExpireOn.Text, System.Globalization.CultureInfo.GetCultureInfo("pt-BR").DateTimeFormat));
        }

        ReloadTasks();

        Response.Redirect("/Tarefas/");
    }

    private void FillTasksOnGrid(Academy.Business.Task task)
    {
        gdvTarefas.DataSource = task.Tasks;
        gdvTarefas.DataBind();
    }
}
