﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Tarefas_Default : System.Web.UI.Page
{
    Academy.Business.Task task = new Academy.Business.Task();

    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            GenerateTasks();
        }
    }

    private void GenerateTasks()
    {
        task.GenerateTasks();
        Session.Add("Tasks", task);
        GetTasks();
    }

    private void GetTasks()
    {
        task = (Academy.Business.Task)Session["Tasks"];
        FillTasksOnGrid(task);
    }

    private void DeleteTasks(int id)
    {
        task = (Academy.Business.Task)Session["Tasks"];
        task.DeleteTask(id);
        FillTasksOnGrid(task);
    }

    protected void gdvTarefas_PageIndexChanging(object sender, GridViewPageEventArgs e)
    {
        gdvTarefas.PageIndex = e.NewPageIndex;
        GetTasks();
    }

    protected void gdvTarefas_RowDataBound(object sender, GridViewRowEventArgs e)
    {

    }

    protected void EditTask(object sender, EventArgs e)
    {
        var id = (sender as LinkButton).CommandArgument;

        task = (Academy.Business.Task)Session["Tasks"];
        var item = task.Tasks.Where(i => i.Id.Equals(Convert.ToInt32(id))).FirstOrDefault();

        Tittle.Text = item.Tittle;
        Description.Text = item.Description;
        ExpireOn.Text = item.ExpireOn.ToString("yyyy-MM-ddTHH:mm:ss");
        Id.Value = id;

        pnlNewTask.Visible = true;
        pnlTask.Visible = false;
    }

    protected void DeleteTask(object sender, EventArgs e)
    {
        var id = (sender as LinkButton).CommandArgument;
        DeleteTasks(Convert.ToInt32(id));
    }

    protected void NewTask(object sender, EventArgs e)
    {
        pnlNewTask.Visible = true;
        pnlTask.Visible = false;
    }

    protected void SaveTask(object sender, EventArgs e)
    {
        var id = 0;
        task = (Academy.Business.Task)Session["Tasks"];

        if (!string.IsNullOrEmpty(Id.Value))
        {
            id = Convert.ToInt32(Id.Value);
            task.Tasks.ForEach(i =>
            {
                if (i.Id.Equals(id))
                {
                    i.Id = id;
                    i.Tittle = Tittle.Text;
                    i.Description = Description.Text;
                    i.ExpireOn = Convert.ToDateTime(ExpireOn.Text, System.Globalization.CultureInfo.GetCultureInfo("pt-BR").DateTimeFormat);
                }
            });
        }
        else
        {
            id = task.Tasks.Max(i => i.Id) + 1;

            var item = new Academy.Model.Task()
            {
                Id = id,
                Tittle = Tittle.Text,
                Description = Description.Text,
                ExpireOn = Convert.ToDateTime(ExpireOn.Text, System.Globalization.CultureInfo.GetCultureInfo("pt-BR").DateTimeFormat)
            };

            task.Tasks.Add(item);
        }

        Session["Tasks"] = task;
        FillTasksOnGrid(task);

        Tittle.Text = string.Empty;
        Description.Text = string.Empty;
        ExpireOn.Text = string.Empty;

        pnlNewTask.Visible = false;
        pnlTask.Visible = true;
    }

    private void FillTasksOnGrid(Academy.Business.Task task)
    {
        gdvTarefas.DataSource = task.Tasks;
        gdvTarefas.DataBind();
    }
}
