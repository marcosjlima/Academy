﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Academy.Model
{
    /// <summary>
    /// Summary description for Tarefas
    /// </summary>
    public class Task
    {
        /// <summary>
        /// identificador do registro
        /// </summary>
        public int Id { get; set; }
        /// <summary>
        /// Titulo da tarefa
        /// </summary>
        public string Tittle { get; set; }
        /// <summary>
        /// Descrição da tarefa
        /// </summary>
        public string Description { get; set; }
        /// <summary>
        /// Descrição curta
        /// </summary>
        public string ShortDescription
        {
            get
            {
                if (Description.Length >= 100)
                    return Description.Substring(0, 100);
                else
                    return Description.Substring(0, Description.Length);
            }
        }
        /// <summary>
        /// Data de criação da tarefa
        /// </summary>
        public DateTime CreatedOn { get; set; }
        /// <summary>
        /// Data de expiração da tarefa
        /// </summary>
        public DateTime ExpireOn { get; set; }
        /// <summary>
        /// Indica se o a tarefa pode ser excluída
        /// </summary>
        public bool Delete { get; set; }
        /// <summary>
        /// Construtor da classe
        /// </summary>
        public Task()
        {
            this.Tittle = string.Empty;
            this.Description = string.Empty;
            this.CreatedOn = DateTime.Now;
            this.ExpireOn = DateTime.MinValue;
        }
    }
}