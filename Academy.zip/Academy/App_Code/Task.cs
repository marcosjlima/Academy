﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace Academy.Business
{
    /// <summary>
    /// Summary description for Task
    /// </summary>
    public class Task
    {
        public List<Model.Task> Tasks { get; private set; }
        private string connAccess = ConfigurationManager.ConnectionStrings["AccessConnectionString"].ConnectionString;

        public Task()
        {
            Tasks = new List<Model.Task>();
        }
        /// <summary>
        /// Responsável por buscar os registros na base de dados
        /// </summary>
        /// <returns>List of Model.Task</returns>
        public List<Model.Task> getTasks()
        {
            Tasks = new List<Model.Task>();

            //cria a conexão com o banco de dados
            using (var conn = new OleDbConnection(connAccess))
            {
                //cria o objeto command and armazena a consulta SQL
                using (var command = new OleDbCommand("SELECT Id, Tittle, Description, CreatedOn, ExpireOn FROM Task", conn))
                {
                    conn.Open();
                    //cria o objeto datareader para fazer a conexao com a tabela
                    var dr = command.ExecuteReader();

                    //Faz a interação com o banco de dados lendo os dados da tabela
                    while (dr.Read())
                    {
                        // Intera sobre os valores
                        Tasks.Add(new Model.Task()
                        {
                            Id = dr.GetInt32(0),
                            Tittle = dr.GetString(1),
                            Description = dr.GetString(2),
                            CreatedOn = dr.GetDateTime(3),
                            ExpireOn = dr.GetDateTime(4),
                            Delete = (dr.GetDateTime(4) >= DateTime.Now.Date)
                        });
                    }
                    //fecha o reader
                    dr.Close();
                    //fecha a conexao
                    conn.Close();
                }
            }

            return Tasks;
        }
        /// <summary>
        /// Responsável por excluir registro(s) da base de dados
        /// </summary>
        /// <param name="id">int</param>
        public void DeleteTask(int id)
        {
            using (var conn = new OleDbConnection(connAccess))
            {
                //cria o objeto command and armazena a consulta SQL
                using (var command = new OleDbCommand("DELETE FROM Task WHERE Id=@Id", conn))
                {
                    // Abre a conexão com o banco
                    conn.Open();
                    
                    // Cria o(s) parametro(s) a serem utilizados nas querys
                    command.Parameters.Add("@id", OleDbType.Integer);
                    command.Parameters["@id"].Value = id;

                    // Faz a exclusão do(s) dado(s)
                    command.ExecuteNonQuery();

                    //fecha a conexao
                    conn.Close();
                }
            }
        }
        /// <summary>
        /// Responsável por atualizar um registro no banco de dados
        /// </summary>
        /// <param name="id">int</param>
        /// <param name="tittle">string</param>
        /// <param name="description">string</param>
        /// <param name="expireOn">datetime</param>
        public void UpdateTask(int id, string tittle, string description, DateTime expireOn)
        {
            using (var conn = new OleDbConnection(connAccess))
            {
                var sqlUpdate = "UPDATE Task SET tittle=@tittle, description=@description, expireOn=@expireOn ";
                sqlUpdate += " WHERE Id=@id";
                //var sqlUpdate = "UPDATE Clientes SET Nome=@tittle, Email=@description WHERE Id=@id"; 
                //cria o objeto command and armazena a consulta SQL
                using (var command = new OleDbCommand(sqlUpdate, conn))
                {
                    // Abre a conexão com o banco
                    conn.Open();

                    // Cria o(s) parametro(s) a serem utilizados nas querys
                    command.Parameters.Add("@tittle", OleDbType.VarChar, 150);
                    command.Parameters.Add("@description", OleDbType.VarChar, 500);
                    command.Parameters.Add("@expireOn", OleDbType.Date);
                    command.Parameters.Add("@id", OleDbType.Integer);
                    command.Parameters["@id"].Value = id;
                    command.Parameters["@tittle"].Value = tittle;
                    command.Parameters["@description"].Value = description;
                    command.Parameters["@expireOn"].Value = expireOn;

                    // Faz a exclusão do(s) dado(s)
                    command.ExecuteNonQuery();

                    //fecha a conexao
                    conn.Close();
                }
            }
        }
        /// <summary>
        /// Responsável por criar um registro no banco de dados
        /// </summary>
        /// <param name="tittle">string</param>
        /// <param name="description">string</param>
        /// <param name="createdOn">datetime</param>
        /// <param name="expireOn">datetime</param>
        public void CreateTask(string tittle, string description, DateTime createdOn, DateTime expireOn)
        {
            using (var conn = new OleDbConnection(connAccess))
            {
                var sqlInsert = "INSERT INTO Task(tittle, description, createdOn, expireOn) ";
                sqlInsert += "VALUES(@tittle, @description, @createdOn, @expireOn)";

                //var sqlInsert = "INSERT INTO Clientes(Nome, Email) VALUES(@tittle, @description)";

                //cria o objeto command and armazena a consulta SQL
                using (var command = new OleDbCommand(sqlInsert, conn))
                {
                    // Abre a conexão com o banco
                    conn.Open();

                    // Cria o(s) parametro(s) a serem utilizados nas querys
                    command.Parameters.Add("@tittle", OleDbType.VarChar, 150);
                    command.Parameters.Add("@description", OleDbType.VarChar, 500);
                    command.Parameters.Add("@createdOn", OleDbType.Date);
                    command.Parameters.Add("@expireOn", OleDbType.Date);

                    command.Parameters["@tittle"].Value = tittle;
                    command.Parameters["@description"].Value = description;
                    command.Parameters["@createdOn"].Value = createdOn;
                    command.Parameters["@expireOn"].Value = expireOn;

                    // Faz a exclusão do(s) dado(s)
                    command.ExecuteNonQuery();

                    //fecha a conexao
                    conn.Close();
                }
            }
        }
    }
}