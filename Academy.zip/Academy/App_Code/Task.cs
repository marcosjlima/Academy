﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Data;
using System.Data.OleDb;
using System.Configuration;

namespace Academy.Business
{
    /// <summary>
    /// Summary description for Task
    /// </summary>
    public class Task
    {
        public List<Model.Task> Tasks { get; private set; }

        public Task()
        {
            Tasks = new List<Model.Task>();
        }

        public List<Model.Task> GenerateTasks()
        {

            //cria a conexão com o banco de dados
            OleDbConnection aConnection = new OleDbConnection(ConfigurationManager.ConnectionStrings["AccessConnectionString"].ConnectionString);

            //cria o objeto command and armazena a consulta SQL
            OleDbCommand aCommand = new OleDbCommand("select * from Clientes", aConnection);

            try
            {
                aConnection.Open();
                //cria o objeto datareader para fazer a conexao com a tabela
                OleDbDataReader aReader = aCommand.ExecuteReader();

                //Faz a interação com o banco de dados lendo os dados da tabela
                while (aReader.Read())
                {
                    // Intera sobre os valores
                    //Console.WriteLine(aReader.GetString(1));
                }
                //fecha o reader
                aReader.Close();
                //fecha a conexao
                aConnection.Close();
            }
            //Trata a exceção
            catch (OleDbException e)
            {
                Console.WriteLine("Error: {0}", e.Errors[0].Message);
            }

            Tasks.Add(new Model.Task()
            {
                Id = 1,
                Tittle = "TCC",
                Description = "Criação do TCC para formação do curso de Analise de Sistemas",
                ExpireOn = DateTime.Now.AddDays(21)
            });
            Tasks.Add(new Model.Task()
            {
                Id = 2,
                Tittle = "Estudar para prova de Cálculo II",
                Description = "Rever materia de cálculo II",
                ExpireOn = DateTime.Now.AddDays(3)
            });
            Tasks.Add(new Model.Task()
            {
                Id = 3,
                Tittle = "Estudar Lorem Impsum",
                Description = "Lorem ipsum dolor sit amet, consectetur adipiscing elit. Vivamus erat ipsum, tempus sed arcu vitae, ornare bibendum magna. Sed efficitur, lacus sed congue venenatis, arcu ex lobortis est, suscipit fringilla nibh libero id velit. Aenean varius, lorem a pellentesque dictum, nisl turpis venenatis sapien, in faucibus ex lacus at tellus. Cras eu enim cursus, ultricies tortor in, pretium velit. Aliquam dui erat, dapibus vitae ex at, euismod blandit urna. Sed non nunc condimentum, facilisis nunc sit amet, laoreet neque. Quisque eu mollis nibh. Curabitur mattis urna ante. Aenean placerat bibendum odio eu maximus. Vivamus volutpat in sem vitae pretium. Mauris molestie tincidunt dui, ac dictum justo eleifend nec. Integer et sem magna.",
                ExpireOn = DateTime.Now.AddDays(20)
            });
            Tasks.Add(new Model.Task()
            {
                Id = 4,
                Tittle = "Estudar Integer vel lectus eget odio hendrerit placerat ut vel sapien",
                Description = "Cras pulvinar tincidunt blandit. Mauris ullamcorper consectetur egestas. Mauris egestas ullamcorper lectus, et pharetra tortor eleifend ac. Vivamus at semper enim, viverra posuere nulla. Aliquam quis odio sapien. Vestibulum ut convallis turpis. Sed vitae diam quis sapien ultrices ultricies. Sed vitae venenatis risus. Interdum et malesuada fames ac ante ipsum primis in faucibus. Nulla posuere, neque in interdum gravida, lacus lorem interdum felis, ut semper magna sapien vitae nisi. Curabitur a rhoncus odio. Sed mollis quam tempus lorem consequat suscipit. Proin elementum, est vitae bibendum placerat, dui leo fringilla massa, at rhoncus erat lorem nec nibh. Proin ipsum erat, sagittis a leo eu, ullamcorper cursus metus.",
                ExpireOn = DateTime.Now.AddDays(15)
            });
            Tasks.Add(new Model.Task()
            {
                Id = 5,
                Tittle = "Estudar Suspendisse ac scelerisque urna",
                Description = "Nam cursus quis nunc quis tempus. Quisque malesuada cursus magna, quis malesuada risus tincidunt eget. Sed ipsum nunc, dictum quis consectetur nec, lacinia tempus quam. Duis blandit rutrum quam, vitae gravida metus mollis ut. Cras et diam ut mi aliquam commodo. Morbi sed eros a elit convallis porta. Nullam sed leo lobortis enim porta auctor. Etiam volutpat feugiat enim, ac euismod nunc lobortis sodales. Donec vestibulum tortor et augue sodales scelerisque. Praesent varius id eros non elementum. Vestibulum ut orci sapien.",
                ExpireOn = DateTime.Now.AddDays(5)
            });
            Tasks.Add(new Model.Task()
            {
                Id = 6,
                Tittle = "Estudar Suspendisse ac scelerisque urna",
                Description = "Nam cursus quis nunc quis tempus. Quisque malesuada cursus magna, quis malesuada risus tincidunt eget. Sed ipsum nunc, dictum quis consectetur nec, lacinia tempus quam. Duis blandit rutrum quam, vitae gravida metus mollis ut. Cras et diam ut mi aliquam commodo. Morbi sed eros a elit convallis porta. Nullam sed leo lobortis enim porta auctor. Etiam volutpat feugiat enim, ac euismod nunc lobortis sodales. Donec vestibulum tortor et augue sodales scelerisque. Praesent varius id eros non elementum. Vestibulum ut orci sapien.",
                ExpireOn = DateTime.Now.AddDays(5)
            });
            Tasks.Add(new Model.Task()
            {
                Id = 7,
                Tittle = "Estudar Suspendisse ac scelerisque urna",
                Description = "Nam cursus quis nunc quis tempus. Quisque malesuada cursus magna, quis malesuada risus tincidunt eget. Sed ipsum nunc, dictum quis consectetur nec, lacinia tempus quam. Duis blandit rutrum quam, vitae gravida metus mollis ut. Cras et diam ut mi aliquam commodo. Morbi sed eros a elit convallis porta. Nullam sed leo lobortis enim porta auctor. Etiam volutpat feugiat enim, ac euismod nunc lobortis sodales. Donec vestibulum tortor et augue sodales scelerisque. Praesent varius id eros non elementum. Vestibulum ut orci sapien.",
                ExpireOn = DateTime.Now.AddDays(5)
            });
            Tasks.Add(new Model.Task()
            {
                Id = 8,
                Tittle = "Estudar Suspendisse ac scelerisque urna",
                Description = "Nam cursus quis nunc quis tempus. Quisque malesuada cursus magna, quis malesuada risus tincidunt eget. Sed ipsum nunc, dictum quis consectetur nec, lacinia tempus quam. Duis blandit rutrum quam, vitae gravida metus mollis ut. Cras et diam ut mi aliquam commodo. Morbi sed eros a elit convallis porta. Nullam sed leo lobortis enim porta auctor. Etiam volutpat feugiat enim, ac euismod nunc lobortis sodales. Donec vestibulum tortor et augue sodales scelerisque. Praesent varius id eros non elementum. Vestibulum ut orci sapien.",
                ExpireOn = DateTime.Now.AddDays(5)
            });
            Tasks.Add(new Model.Task()
            {
                Id = 9,
                Tittle = "Estudar Suspendisse ac scelerisque urna",
                Description = "Nam cursus quis nunc quis tempus. Quisque malesuada cursus magna, quis malesuada risus tincidunt eget. Sed ipsum nunc, dictum quis consectetur nec, lacinia tempus quam. Duis blandit rutrum quam, vitae gravida metus mollis ut. Cras et diam ut mi aliquam commodo. Morbi sed eros a elit convallis porta. Nullam sed leo lobortis enim porta auctor. Etiam volutpat feugiat enim, ac euismod nunc lobortis sodales. Donec vestibulum tortor et augue sodales scelerisque. Praesent varius id eros non elementum. Vestibulum ut orci sapien.",
                ExpireOn = DateTime.Now.AddDays(5)
            });
            Tasks.Add(new Model.Task()
            {
                Id = 10,
                Tittle = "Estudar Suspendisse ac scelerisque urna",
                Description = "Nam cursus quis nunc quis tempus. Quisque malesuada cursus magna, quis malesuada risus tincidunt eget. Sed ipsum nunc, dictum quis consectetur nec, lacinia tempus quam. Duis blandit rutrum quam, vitae gravida metus mollis ut. Cras et diam ut mi aliquam commodo. Morbi sed eros a elit convallis porta. Nullam sed leo lobortis enim porta auctor. Etiam volutpat feugiat enim, ac euismod nunc lobortis sodales. Donec vestibulum tortor et augue sodales scelerisque. Praesent varius id eros non elementum. Vestibulum ut orci sapien.",
                ExpireOn = DateTime.Now.AddDays(5)
            });

            return Tasks;
        }

        public List<Model.Task> DeleteTask(int id)
        {
            Tasks.RemoveAll(i => i.Id.Equals(id));

            return Tasks;
        }
    }
}